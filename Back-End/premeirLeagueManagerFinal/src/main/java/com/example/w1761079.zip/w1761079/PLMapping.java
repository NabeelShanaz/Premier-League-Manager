package com.example.w1761079;

import com.example.FootballClub;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PLMapping {
    static List<FootballClub> list = new ArrayList<>();
    static { list.add(new FootballClub("ColomboKing","colombo",1,1,1,1,1,1,1));
    }

    public List<FootballClub> football(){
        return this.list;
    }
}

