package com.example.w1761079;

import com.example.FootballClub;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@CrossOrigin(origins = "http://localhost:4200/%22")

@RestController
public class RestAPI {
    private PLMapping plmapp = new PLMapping();

    @GetMapping("/app-premeir-league-table")
    public List<FootballClub> getRequest(){
        return plmapp.football();
    }

}
